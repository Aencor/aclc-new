<?php


namespace WPML\INSTALLER\FP;

class Undefined {

}