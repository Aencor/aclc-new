<?php

namespace WPML\INSTALLER\FP;

class Promise {

	private $onResolved;

	private $onReject;

	private $next;

	public function resolve( $data ) {
		if ( $this->onResolved ) {
			if ( $data instanceof Either ) {
				$result = $data->chain( $this->onResolved );
			} else {
				$result = call_user_func( $this->onResolved, $data );
			}
			if ( $this->next ) {
				if ( $result && ! $result instanceof Left ) {
					return $this->next->resolve( $result );
				} else {
					return $this->next->reject( $result );
				}
			} else {
				return $result;
			}
		} else {
			return $data;
		}
	}

	public function reject( $data ) {
		$result = $data;
		if ( $this->onReject ) {
			if ( $data instanceof Either ) {
				$result = $data->orElse( $this->onReject )->join();
			} else {
				$result = call_user_func( $this->onReject, $data );
			}
		}
		if ( $this->next ) {
			return $this->next->reject( $result );
		} else {
			return $result;
		}
	}

	public function then( callable $fn ) {
		$this->onResolved = $fn;
		$this->next       = new Promise();

		return $this->next;
	}

	public function onError( callable $fn ) {
		$this->onReject = $fn;
		$this->next     = new Promise();

		return $this->next;
	}

}
