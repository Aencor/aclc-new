<?php

namespace WPML\INSTALLER\FP;

trait ConstApplicative {

	public function ap( $otherContainer ) {
		return $this;
	}
}
