<?php

namespace WPML\INSTALLER\FP\Functor;

class ConstFunctor {
	use Functor;
	use Pointed;

	public function map( $callback ) {
		return $this;
	}
}
