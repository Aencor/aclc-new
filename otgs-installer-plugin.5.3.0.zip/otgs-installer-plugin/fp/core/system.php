<?php

namespace WPML\INSTALLER\FP\System;

function getFilterFor( $key ) {
	return new _Filter( $key );
}

function filterVar( $filter ) {
	return function ( $var ) use ( $filter ) {
		return filter_var( $var, $filter );
	};
}

function sanitizeString() {
	return function ( $var ) {
		return htmlspecialchars( strip_tags( $var ) );
	};
}

function getValidatorFor( $key ) {
	return new _Validator( $key );
}

