<?php

namespace WPML\INSTALLER\FP;

use WPML\Collect\Support\Traits\Macroable;

class Cast {
	use Macroable;

	public static function init() {
		self::macro( 'toBool', curryN( 1, function ( $v ) {
			return (bool) $v;
		} ) );
		self::macro( 'toInt', curryN( 1, function ( $v ) {
			return intval( $v );
		} ) );
	}
}

Cast::init();
