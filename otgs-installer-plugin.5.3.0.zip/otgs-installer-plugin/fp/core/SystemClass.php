<?php

namespace WPML\INSTALLER\FP\System;

use WPML\INSTALLER\FP\Either;

class System {

	public static function getPostData() {
		return function () {
			return Either::right( wpml_collect( $_POST ) );
		};
	}
}
