<?php

namespace WPML\INSTALLER\FP\Strings;

use function WPML\INSTALLER\FP\partial;
use function WPML\INSTALLER\FP\partialRight;
use function WPML\INSTALLER\FP\pipe;

function ltrimWith( $trim ) {
	return partialRight( 'ltrim', $trim );
}

function rtrimWith( $trim ) {
	return partialRight( 'rtrim', $trim );
}

function explodeToCollection( $delimiter ) {
	return pipe( partial( 'explode', $delimiter ), 'wpml_collect' );
}

function replace( $search, $replace ) {
	return partial( 'str_replace', $search, $replace );
}

function remove( $remove ) {
	return partial( 'str_replace', $remove, '' );
}

