<?php

namespace OTGS\InstallerPlugin;

use WPML\INSTALLER\FP\Maybe;
use WPML\INSTALLER\FP\Obj;
use WPML\INSTALLER\FP\Relation;
use WPML\INSTALLER\FP\Str;

class PluginDeactivator {

	const REASON_OPTION = 'otgs_installer_plugin_deactivated';

	public static function deactivateIfRequired( $ownActivation = false ) {
		return function () use ( $ownActivation ) {
			global $wp_installer_instances;
			$allInstances = \wpml_collect( $wp_installer_instances );

			$highestVersion = $allInstances->max( 'version' );

			$amIDelegated = function ( $instance ) use ( $highestVersion ) {
				return (bool) Maybe::of( $instance )
				                   ->filter( Relation::propEq( 'version', $highestVersion ) )
				                   ->map( Obj::prop( 'bootfile' ) )
				                   ->map( Str::pos( OTGS_INSTALLER_PLUGIN_FOLDER ) )
				                   ->getOrElse( false );
			};

			$hasInstancesWithSameVersion = function ( $delegatedInstance ) use ( $allInstances ) {
				return $allInstances->reject( Relation::propEq( 'bootfile', Obj::prop( 'bootfile', $delegatedInstance ) ) )
				                    ->filter( Relation::propEq( 'version', Obj::prop( 'version', $delegatedInstance ) ) )
				                    ->count() > 0;
			};

			$delegatedInstance = $allInstances
				->first( $amIDelegated );

			$shouldDisable = ! $delegatedInstance || $hasInstancesWithSameVersion( $delegatedInstance );

			if ( $shouldDisable ) {
				$isCli = defined( 'WP_CLI' ) && WP_CLI && class_exists( 'WP_CLI' );

				update_option(
					self::REASON_OPTION,
					[
						'own_activation' => $ownActivation && ! $isCli,
						'plugin'         => OTGS_INSTALLER_PLUGIN_BASENAME,
						'time'           => time(),
					],
					false
				);
				deactivate_plugins( OTGS_INSTALLER_PLUGIN_BASENAME );

				if ( $ownActivation && $isCli ) {
					\WP_CLI::warning( 'OTGS Installer was deactivated again: another active plugin already includes the Installer.' );
				}
			}
		};
	}
}
